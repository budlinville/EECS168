public class Ex2 {
	public static void main(String[] args) {
		System.out.println("My name is Bud Linville."
		+ "\nI am an EECS major."
		+ "\nMy hobbies are:"
		+ "\n\tCoding"
		+ "\n\tFantasy Football"
		+ "\n\tSkiiing"
		+ "\n\tFishing"
		+ "\nGoodbye");
	}
}
