public class Ex1 {
	public static void main(String[] args){
		System.out.println("This is my second java program");
	}
}
